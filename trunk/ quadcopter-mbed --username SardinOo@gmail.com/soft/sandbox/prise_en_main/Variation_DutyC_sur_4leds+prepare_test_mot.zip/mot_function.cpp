
#include "lib_mot_function.h"

void PWM_mot(char input)
{
    switch (input) 
    {
          case '1':
            motfront.period_ms(period_mot_ms);
            motfront=motfront+duty_cycle_mot;
            if (motfront>=0.1)motfront=0.1; 
           // return motfront;
            break;
            
            
          case '7':
            motfront.period_ms(period_mot_ms);
            motfront=motfront-duty_cycle_mot;
            if (motfront<=0)motfront=0; 
           // return motfront;
            break;
            

         case '2':
            motback.period_ms(period_mot_ms);
            motback=motback+duty_cycle_mot;
            if (motback>0.1)motback=0.1; 
           // return motback;
            break;
            
            
          case '8':
            motback.period_ms(period_mot_ms);
            motback=motback-duty_cycle_mot;
            if (motback<=0)motback=0; 
            //return motback;
            break;
            
            
            
          case '3':
            motleft.period_ms(period_mot_ms);
            motleft=motleft+duty_cycle_mot;
            if (motleft>0.1)motleft=0.1; 
           // return motleft;
            break;
            

            case '9':
            motleft.period_ms(period_mot_ms);
            motleft=motleft-duty_cycle_mot;
            if (motleft<0)motleft=0; 
            //return motleft; 
            break;
             
            
          case '4':
            motright.period_ms(period_mot_ms);
            motright=motright+duty_cycle_mot;
            if (motright>0.1)motright=0.1; 
           // return motright;
            break;
           
           
          case '6':
            motright.period_ms(period_mot_ms);
            motright=motright-duty_cycle_mot;
            if (motright<0)motright=0; 
           // return motright;
            break;
           
           
          case '5':
            motfront.period_ms(period_mot_ms);
            motback.period_ms(period_mot_ms);
            motleft.period_ms(period_mot_ms);
            motright.period_ms(period_mot_ms);
            motfront=0.05;
            motback=0.05;
            motright=0.05;
            motleft=0.05;
           // return motright;
            break;
            
            case '0':
            motfront.period_ms(period_mot_ms);
            motback.period_ms(period_mot_ms);
            motleft.period_ms(period_mot_ms);
            motright.period_ms(period_mot_ms);
            motfront=0.0;
            motback=0.0;
            motright=0.0;
            motleft=0.0;
           // return motright;
            break;
      
        }   
   
}
