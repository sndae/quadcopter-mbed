#ifndef lib_OK
#define lib_OK

#include "mbed.h"

/*---- Declaration des #define ----*/
#define period_mot_ms 20
#define duty_cycle_mot 0.01

/*---- Declaration des PWMs ----*/
PwmOut motfront(LED1);
PwmOut motback(LED2);
PwmOut motleft(LED3);
PwmOut motright(LED4);

/* --- Prototypes ----*/


//void PWM_mot(char input);

#endif