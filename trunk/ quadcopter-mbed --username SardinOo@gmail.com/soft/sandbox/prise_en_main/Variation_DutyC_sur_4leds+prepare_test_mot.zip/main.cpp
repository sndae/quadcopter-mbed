
#include "mbed.h"
#include "lib_prototype.h"

/*---- Declaration du Serial PORT ----*/
Serial pc(USBTX, USBRX);

/*----D&#65533;claration de l'interruption----*/

/*---- Declaration variable globales ----*/
char input;


int main()
 {
   // Live.attach(Live_isr, 100); //PWM 20ms + Variation DutyCycle

    pc.printf("Motfront = 1\r\n");
    pc.printf("Motback  = 2\r\n");
    pc.printf("Motleft  = 3\r\n");
    pc.printf("Motright = 4\r\n");

    while (1) 
    {
        input = pc.getc();
        PWM_mot(input);
    }
}


 /*

void Live_isr()
{
        pc.printf("Motfront: %f\r\n",motfront);
        pc.printf("Motback: %f\r\n",motback);
        pc.printf("Motleft: %f\r\n",motleft);
        pc.printf("Motright: %f\r\n",motright);                             
        pc.printf("Duty cycle:%f\r\n", PWM_mot(input));   //Affichage du DutyCycle
}
*/
