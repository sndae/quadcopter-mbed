
#include "mbed.h"

/*---- Declaration des #define ----*/
#define period_mot 10
#define duty_cycle_mot 0.05

/*---- D&#65533;claration des PWMs ----*/
PwmOut motfront(LED1);
PwmOut motback(LED2);
PwmOut motleft(LED3);
PwmOut motright(LED4);

/*---- D&#65533;claration du Serial PORT ----*/
Serial pc(USBTX, USBRX);

/*----D�claration de l'interruption----*/
Ticker Live;

/*---- Prototypes de fonctions ----*/
float DecodeInput(char input);
void Live_isr();
void Shutdownled(void);

/*---- Declaration variable globales ----*/
 char input;


int main()
 {
 
   // Live.attach(Live_isr, 100); //PWM 20ms + Variation DutyCycle
    motfront = 0;
    motback  = 0; 
    motleft  = 0;
    motright = 0;
    pc.printf("Motfront = 1\r\n");
    pc.printf("Motback  = 2\r\n");
    pc.printf("Motleft  = 3\r\n");
    pc.printf("Motright = 4\r\n");

    while (1) 
    {
        input = pc.getc();
         DecodeInput(input);
    }
}

/*---- Fonction de variation de PWM avec + et - sur led1 ----*/
float DecodeInput(char input) {

    switch (input) {
         case '1':
            motfront.period_ms(period_mot);
            motfront=motfront+duty_cycle_mot;
            if (motfront>1)motfront=1; break;
            break;
            return motfront;
            
          case '7':
            motfront.period_ms(period_mot);
            motfront=motfront-duty_cycle_mot;
            if (motfront<=0)motfront=0; break;
            break;
            return motfront;

         case '2':
            motback.period_ms(period_mot);
            motback=motback+duty_cycle_mot;
            if (motback>1)motback=1; break;
            break;
            return motback;
            
            case '8':
            motback.period_ms(period_mot);
            motback=motback-duty_cycle_mot;
            if (motback<=0)motback=0; break;
            break;
            return motback;
            
            
         case '3':
            motleft.period_ms(period_mot);
            motleft=motleft+duty_cycle_mot;
            if (motleft>1)motleft=1; break;
            break;
            return motleft;

            case '9':
            motleft.period_ms(period_mot);
            motleft=motleft-duty_cycle_mot;
            if (motleft<01)motleft=0; break;
            break;
            return motleft;  
            
         case '4':
            motright.period_ms(period_mot);
            motright=motright+duty_cycle_mot;
            if (motright>1)motright=1; break;
            break;
           return motright;
           
          case '6':
            motright.period_ms(period_mot);
            motright=motright-duty_cycle_mot;
            if (motright<0)motright=0; break;
            break;
           return motright;
           
           default: break;
    }
    
  //  input=0;

 }

void Live_isr()
{
        pc.printf("Motfront: %f\r\n",motfront);
        pc.printf("Motback: %f\r\n",motback);
        pc.printf("Motleft: %f\r\n",motleft);
        pc.printf("Motright: %f\r\n",motright);                             
        pc.printf("Duty cycle:%f\r\n", DecodeInput(input));   //Affichage du DutyCycle
}

/*---- Shutdown toutes les leds ---*/
/*void Shutdownled() {
    myled1 = 0;
    myled2 = 0;
    myled3 = 0;
    myled4 = 0;

    return;
}*/