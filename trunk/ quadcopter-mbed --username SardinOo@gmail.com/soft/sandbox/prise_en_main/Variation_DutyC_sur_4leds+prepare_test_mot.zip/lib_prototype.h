/*---- Prototype function ---*/

void PWM_mot(char input);