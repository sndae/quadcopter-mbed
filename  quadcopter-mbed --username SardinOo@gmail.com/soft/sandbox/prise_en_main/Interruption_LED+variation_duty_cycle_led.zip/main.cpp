
#include "mbed.h"

/*---- D�claration des PWMs ----*/
PwmOut myled1(LED1);
DigitalOut myled2(LED2);
PwmOut myled3(LED3);
PwmOut myled4(LED4);

/*---- D�claration du Serial PORT ----*/
Serial pc(USBTX, USBRX);

Ticker Live;

/*---- Prototypes de fonctions ----*/
float DecodeInput(char input);
void Live_isr();
void Shutdownled(void);


int main()
 {
 char input;
    Live.attach(Live_isr, 0.1);
    myled2=1;

    while (1) 
    {
        input = pc.getc();                                     
        pc.printf("Received: %c\r\n", input);                  //Key re�ue
        pc.printf("Duty cycle:%f\r\n", DecodeInput(input));   //Affichage du DutyCycle
    }
}

/*---- Fonction de variation de PWM avec + et - sur led1 ----*/
float DecodeInput(char input) {

    switch (input) {
        case '+':
            myled1.period_ms(100);
            myled1=myled1+0.1;
            if (myled1>1)myled1=1; break;
            break;

        case '-':
            myled1.period_ms(100);
            myled1=myled1-0.1;
            if (myled1<0)myled1=0; break;
            break;

        default:
            Shutdownled();
            break;
    }

    return myled1;
}

void Live_isr()
{
    myled2 = !myled2;
    myled3 = !myled3;
}

/*---- Shutdown toutes les leds ---*/
void Shutdownled() {
    myled1 = 0;
    myled2 = 0;
    myled3 = 0;
    myled4 = 0;

    return;
}