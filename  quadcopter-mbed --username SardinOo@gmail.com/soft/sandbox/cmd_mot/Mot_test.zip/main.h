
/*---- Declaration define ----*/

#define INC_motfront 1
#define DEC_motfront 7

#define INC_motback  2
#define DEC_motback  8

#define INC_motleft  3
#define DEC_motleft  9

#define INC_motright 4
#define DEC_motright 6

#define INC_motall   5
#define DEC_motall   0

/*---- Declaration du Serial PORT ----*/
Serial serial(USBTX, USBRX);

/*---- Declaration des interruptions----*/

/*---- Declaration variable globales ----*/
short JoyX,JoyY,AccX,AccY,AccZ,ButtonZ,ButtonC;

/*---- Declaration de focntion in main ----*/ 
void  ReadAndReport(WiiNunchuckReader* const nchk, const char* const portname)
{
    int bufSize = 0;
    char* bufPtr = NULL;
    bool debug = true;

    nchk->RequestRead();
   // serial.printf("%s: ", portname);
        
    if (debug)
    {
        bufSize = nchk->getBufferSize();
        bufPtr = nchk->getReadBuf();
        if (bufPtr != NULL)
        {
            for (int i = 0; i < bufSize; i++)
            {
                //serial.printf("%x ", bufPtr[i]);
            }
            serial.printf("\r\n");
        }
    }
        
        
    ButtonZ = nchk->getButtonZ();
    ButtonC = nchk->getButtonC();
    AccX = nchk->getAccelX();
    AccY = nchk->getAccelY();
    AccZ = nchk->getAccelZ();
    JoyX = nchk->getJoyX();
    JoyY = nchk->getJoyY();
        
    /*serial.printf("Z:%d\t\n\r", nchk->getButtonZ());
    serial.printf("C:%d\t\n\r", nchk->getButtonC());
    serial.printf("AccX%d\t\n\r", nchk->getAccelX());
    serial.printf("AccY%d\t\n\r", nchk->getAccelY());
    serial.printf("AccZ%d\t\n\r", nchk->getAccelZ());
    serial.printf("JoyY%d\t\n\r", nchk->getJoyY());
   /* serial.printf("JoyY%d\r\n\r", nchk->getJoyY());
    serial.printf("\r\n");*/
    
}



