
#include "mbed.h"
#include "I2CConfig.h"
#include "WiiNunchuckReader.h"
#include "lib_prototype.h"
#include "main.h"


/*---- Declaration des interruptions----*/

int main()
 {
    char choix_moteur = 0;
    float dc_mot =0;
    
    WiiNunchuckReader nchkB(I2CPort_B::SDA, I2CPort_B::SCL);
     
    while (1) 
    {
        ReadAndReport(&nchkB, "PORT B");
        
       if( ((JoyY < 100) ||  (JoyY > 130)) && (ButtonZ))
       {    
           if( JoyY< 100) choix_moteur = DEC_motall; dc_mot = (JoyY*0.005)/220;
           if( JoyY> 130) choix_moteur = INC_motall; dc_mot = (JoyY*0.005)/220;
       }
       
        printf("JoyY: %d\n\r", JoyY);
        printf("dcmot:%f\n\r", dc_mot);
        printf("input: %d\n\r", choix_moteur);
          
         PWM_mot(choix_moteur,dc_mot);
         choix_moteur = 10 ;
     
         
        
            
    }
       

}


