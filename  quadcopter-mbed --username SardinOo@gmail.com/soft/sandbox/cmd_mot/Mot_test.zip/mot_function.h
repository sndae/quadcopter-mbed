#ifndef lib_OK
#define lib_OK

#include "mbed.h"


/*---- Declaration des #define ----*/
#define period_mot_ms 20
//#define duty_cycle_mot 0.005

/*---- Declaration des PWMs ----*/
/*PwmOut motfront(p21);
PwmOut motback(p22);
PwmOut motleft(p23);
PwmOut motright(p24);*/
PwmOut motfront(LED1);
PwmOut motback(LED2);
PwmOut motleft(LED3);
PwmOut motright(LED4);



#endif