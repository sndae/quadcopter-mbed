#include "mot_function.h"

/*---- VARIATION VITESSE MOTEUR ----*/
void PWM_mot(char input, float duty_cycle_mot)
{
    switch (input) 
    {
       /*---- MOT Front----*/
          case '1':
            motfront.period_ms(period_mot_ms);
            motfront=motfront+duty_cycle_mot;
            break;
            
            
          case '7':
            motfront.period_ms(period_mot_ms);
            motfront=motfront-duty_cycle_mot;
            break;
            
        /*---- MOT Back----*/
         case '2':
            motback.period_ms(period_mot_ms);
            motback=motback+duty_cycle_mot;
            break;
            
            
          case '8':
            motback.period_ms(period_mot_ms);
            motback=motback-duty_cycle_mot;
            break;
            
        /*---- MOT Left ----*/
          case '3':
            motleft.period_ms(period_mot_ms);
            motleft=motleft+duty_cycle_mot;
            break;
            

          case '9':
            motleft.period_ms(period_mot_ms);
            motleft=motleft-duty_cycle_mot;
            break;
             
          /*--- MOT Right ----*/  
          case '4':
            putchar('1');
            motright.period_ms(period_mot_ms);
            motright=motright+duty_cycle_mot;
            break;
           
           
          case '6':
            motright.period_ms(period_mot_ms);
            motright=motright-duty_cycle_mot;
            break;
           
         /*---- MOT ALL ----*/   
          case '5':
            motfront.period_ms(period_mot_ms);
            motback.period_ms(period_mot_ms);
            motleft.period_ms(period_mot_ms);
            motright.period_ms(period_mot_ms);
            motfront=motfront+duty_cycle_mot;
            motback=motback+duty_cycle_mot;
            motright=motright+duty_cycle_mot;
            motleft=motleft+duty_cycle_mot;
            printf("motfront:%f\n\r",motfront);
            break;
            
          case '0':
            motfront.period_ms(period_mot_ms);
            motback.period_ms(period_mot_ms);
            motleft.period_ms(period_mot_ms);
            motright.period_ms(period_mot_ms);
            motfront=motfront-duty_cycle_mot;
            motback=motback-duty_cycle_mot;
            motright=motright-duty_cycle_mot;
            motleft=motleft-duty_cycle_mot;
            break;
            
          case '11': 
            motfront.period_ms(period_mot_ms);
            motback.period_ms(period_mot_ms);
            motleft.period_ms(period_mot_ms);
            motright.period_ms(period_mot_ms);
            motfront=0.1;
            motback=0.1;
            motright=0.1;
            motleft=0.1;
      
        }   
        
        /*--- LIMITATION DU DUTY CYCLE 0 TO 0.1 ----*/
        motfront>=0.1 ? motfront=0.1 : motfront=motfront;
        motback>=0.1 ? motback=0.1 : motback=motback;
        motleft>=0.1 ? motleft=0.1 : motleft=motleft; 
        motright>=0.1 ? motright=0.1 : motright=motright;
        
 }
