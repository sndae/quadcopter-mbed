
/*---- Prototype function ---*/
void PWM_mot(char input, float duty_cycle_mot);
void ReadAndReport(WiiNunchuckReader* const nchk, const char* const portname);